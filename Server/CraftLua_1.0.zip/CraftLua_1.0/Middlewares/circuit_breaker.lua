local M = {}
local failure_count = 0
local threshold = 5

function M.record_error()
    failure_count = failure_count + 1
end

function M.is_tripped()
    return failure_count >= threshold
end

function M.reset()
    failure_count = 0
end

return M