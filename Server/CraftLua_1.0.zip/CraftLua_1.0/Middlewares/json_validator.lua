local M = {}

function M.is_json(content_type)
    if not content_type then return false end
    return content_type:find("application/json", 1, true) ~= nil
end

function M.validate_structure(body)
    if not body or body == "" then return false end
    local first = body:match("^%s*(.)")
    return first == "{" or first == "["
end

return M