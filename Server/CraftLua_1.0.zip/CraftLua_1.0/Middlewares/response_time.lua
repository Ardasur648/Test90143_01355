local M = {}

function M.start()
    return os.clock()
end

function M.end_timer(start_time)
    return math.floor((os.clock() - start_time) * 1000)
end

return M