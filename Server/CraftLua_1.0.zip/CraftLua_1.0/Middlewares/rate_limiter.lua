local M = {}
local tracker = {}

function M.check(client_ip)
    local current_time = os.time()
    tracker[client_ip] = tracker[client_ip] or { count = 0, time = current_time }
    
    if current_time - tracker[client_ip].time > 1 then
        tracker[client_ip].count = 1
        tracker[client_ip].time = current_time
        return true
    end

    tracker[client_ip].count = tracker[client_ip].count + 1
    if tracker[client_ip].count > 50 then
        return false
    end

    return true
end

return M