local M = {}

local types = {
    ["html"] = "text/html; charset=utf-8",
    ["css"] = "text/css; charset=utf-8",
    ["js"] = "application/javascript; charset=utf-8",
    ["json"] = "application/json; charset=utf-8",
    ["png"] = "image/png",
    ["jpg"] = "image/jpeg"
}

function M.get(filename)
    local ext = filename:match("^.+(%..+)$")
    if ext then
        ext = ext:sub(2):lower()
        return types[ext] or "application/octet-stream"
    end
    return "text/plain; charset=utf-8"
end

return M