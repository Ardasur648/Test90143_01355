local M = {}

function M.build(metrics)
    local parts = {}
    for name, duration in pairs(metrics) do
        table.insert(parts, string.format('%s;dur=%.2f', name, duration))
    end
    return table.concat(parts, ", ")
end

return M