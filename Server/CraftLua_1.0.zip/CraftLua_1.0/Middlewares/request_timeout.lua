local M = {}

function M.check(start_time, timeout_limit)
    timeout_limit = timeout_limit or 10
    local elapsed = os.time() - start_time
    if elapsed > timeout_limit then
        return false
    end
    return true
end

return M