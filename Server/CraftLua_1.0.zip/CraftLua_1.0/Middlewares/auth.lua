local M = {}

function M.verify(headers)
    local auth_header = headers["Authorization"]
    if not auth_header then
        return false
    end
    
    if auth_header:match("^Bearer%s+(.+)$") then
        return true
    end

    return false
end

return M