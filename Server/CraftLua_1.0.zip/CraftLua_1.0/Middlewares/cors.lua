local M = {}

function M.apply(response_headers)
    response_headers["Access-Control-Allow-Origin"] = "*"
    response_headers["Access-Control-Allow-Methods"] = "GET, POST, PUT, DELETE, OPTIONS"
    response_headers["Access-Control-Allow-Headers"] = "Content-Type, Authorization"
    return response_headers
end

return M