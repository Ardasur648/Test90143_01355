local M = {}

function M.accepts(accept_header, target_type)
    if not accept_header or accept_header:find("*/*") then
        return true
    end
    if accept_header:find(target_type, 1, true) then
        return true
    end
    return false
end

return M