local M = {}

function M.parse(range_header, file_size)
    if not range_header then return nil, nil end
    local start_bytes, end_bytes = range_header:match("bytes=(%d+)%-(%d*)")
    if not start_bytes then return nil, nil end
    
    local start_idx = tonumber(start_bytes)
    local end_idx = end_bytes ~= "" and tonumber(end_bytes) or (file_size - 1)
    
    if start_idx >= file_size then return nil, nil end
    if end_idx >= file_size then end_idx = file_size - 1 end
    
    return start_idx, end_idx
end

return M