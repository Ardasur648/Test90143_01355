local M = {}

function M.catch(err_msg)
    local body = '{"error": "Internal Server Error", "details": "' .. tostring(err_msg) .. '"}'
    local response = "HTTP/1.1 500 Internal Server Error\r\n" ..
                     "Content-Type: application/json; charset=utf-8\r\n" ..
                     "Content-Length: " .. string.len(body) .. "\r\n" ..
                     "Connection: close\r\n\r\n" .. 
                     body
    return response
end

return M