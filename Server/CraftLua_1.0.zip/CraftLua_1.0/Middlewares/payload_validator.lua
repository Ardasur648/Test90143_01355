local M = {}
local MAX_SIZE = 1048576

function M.validate(body_string)
    if #body_string > MAX_SIZE then
        return false
    end
    return true
end

return M