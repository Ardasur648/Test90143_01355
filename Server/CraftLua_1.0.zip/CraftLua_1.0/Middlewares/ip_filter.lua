local M = {}
local blacklist = {
    ["192.168.1.100"] = true,
    ["10.0.0.99"] = true
}

function M.check(ip)
    if blacklist[ip] then
        return false
    end
    return true
end

return M