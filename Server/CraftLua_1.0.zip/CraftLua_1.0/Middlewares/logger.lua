local M = {}

function M.handle(client, request_line)
    local timestamp = os.date("%Y-%m-%d %H:%M:%S")
    print(string.format("[%s] Запрос: %s", timestamp, request_line))
    return true
end

return M