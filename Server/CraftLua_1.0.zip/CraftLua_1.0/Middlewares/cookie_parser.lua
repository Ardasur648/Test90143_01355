local M = {}

function M.parse(cookie_string)
    local cookies = {}
    if not cookie_string then
        return cookies
    end
    for key, value in cookie_string:gmatch("([^=;%s]+)=([^;]+)") do
        cookies[key] = value
    end
    return cookies
end

return M