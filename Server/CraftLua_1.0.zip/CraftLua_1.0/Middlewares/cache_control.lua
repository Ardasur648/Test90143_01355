local M = {}

function M.apply(headers, max_age)
    max_age = max_age or 3600
    headers["Cache-Control"] = "public, max-age=" .. tostring(max_age)
    return headers
end

return M