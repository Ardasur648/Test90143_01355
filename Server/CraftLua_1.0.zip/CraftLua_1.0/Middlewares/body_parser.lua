local M = {}

function M.parse(request_string)
    local _, body_start = request_string:find("\r\n\r\n")
    if not body_start then
        return ""
    end
    return request_string:sub(body_start + 1)
end

return M