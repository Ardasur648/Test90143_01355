local M = {}

function M.redirect(proto, host, uri)
    if proto ~= "https" then
        return "HTTP/1.1 301 Moved Permanently\r\n" ..
                 "Location: https://" .. host .. uri .. "\r\n" ..
                 "Connection: close\r\n\r\n"
    end
    return nil
end

return M