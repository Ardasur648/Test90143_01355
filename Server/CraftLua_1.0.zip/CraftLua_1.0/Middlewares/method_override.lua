local M = {}

function M.override(headers, current_method)
    local override = headers["X-HTTP-Method-Override"]
    if override and current_method == "POST" then
        return override:upper()
    end
    return current_method
end

return M