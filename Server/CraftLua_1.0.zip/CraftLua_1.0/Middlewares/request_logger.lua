local M = {}

function M.format(method, path, status, duration)
    return string.format("[%s] %s -> %d (%dms)", method, path, status, duration)
end

return M