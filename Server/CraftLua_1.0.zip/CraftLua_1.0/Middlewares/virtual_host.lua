local M = {}

function M.match(host_header)
    local allowed_hosts = {
        ["localhost"] = true,
        ["127.0.0.1"] = true
    }
    if host_header then
        local domain = host_header:match("^([^:]+)")
        if allowed_hosts[domain] then
            return true
        end
    end
    return false
end

return M