local M = {}

function M.generate(content)
    local hash = 0
    for i = 1, #content do
        hash = (hash * 31 + content:byte(i)) % 4294967296
    end
    return '"' .. string.format("%x", hash) .. '"'
end

function M.matches(client_etag, server_etag)
    return client_etag == server_etag
end

return M