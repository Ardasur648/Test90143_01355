local M = {}

function M.parse(query_string)
    local params = {}
    if not query_string then
        return params
    end
    for key, value in query_string:gmatch("([^&=]+)=([^&]+)") do
        params[key] = value
    end
    return params
end

return M