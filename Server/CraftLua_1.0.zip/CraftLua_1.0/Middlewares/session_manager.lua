local M = {}
local sessions = {}

function M.create(session_id, data)
    sessions[session_id] = {
        data = data,
        expires = os.time() + 3600
    }
end

function M.get(session_id)
    local session = sessions[session_id]
    if session and session.expires > os.time() then
        return session.data
    end
    sessions[session_id] = nil
    return nil
end

return M