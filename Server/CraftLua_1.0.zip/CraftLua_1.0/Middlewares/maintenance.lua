local M = {}
local maintenance_mode = false

function M.set_status(status)
    maintenance_mode = status
end

function M.check()
    if maintenance_mode then
        return "HTTP/1.1 503 Service Unavailable\r\nContent-Type: text/plain; charset=utf-8\r\nConnection: close\r\n\r\nServer is under maintenance"
    end
    return nil
end

return M