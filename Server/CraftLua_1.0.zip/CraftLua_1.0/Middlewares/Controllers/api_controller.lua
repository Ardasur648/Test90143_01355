local M = {}

function M.handle(req, res)
    local body = '{"message": "Hello from CraftLua API", "version": "0.5"}'
    return 200, "application/json; charset=utf-8", body
end

return M