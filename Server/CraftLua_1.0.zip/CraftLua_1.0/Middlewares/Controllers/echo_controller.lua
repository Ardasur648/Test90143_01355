local M = {}

function M.handle(req, res)
    local body = '{"method": "' .. tostring(req.method) .. '", "uri": "' .. tostring(req.uri) .. '"}'
    return 200, "application/json; charset=utf-8", body
end

return M