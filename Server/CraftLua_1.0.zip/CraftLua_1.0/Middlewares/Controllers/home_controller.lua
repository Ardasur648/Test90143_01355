local M = {}

function M.handle(req, res)
    local body = "<html><body><h1>Welcome to CraftLua</h1></body></html>"
    return 200, "text/html; charset=utf-8", body
end

return M