const std = @import("std");

pub const Hasher = struct {
    pub fn computeFnv1a(data: []const u8) u32 {
        var hash: u32 = 2166136261;
        for (data) |byte| {
            hash ^= byte;
            hash +%= (hash *% 16777619);
        }
        return hash;
    }
};