local M = {}

function M.handle(req, res)
    local body = '{"status": "ok", "uptime": ' .. tostring(os.time()) .. '}'
    return 200, "application/json; charset=utf-8", body
end

return M