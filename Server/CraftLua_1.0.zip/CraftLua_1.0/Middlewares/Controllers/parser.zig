const std = @import("std");

pub const HttpParser = struct {
    method: []const u8,
    uri: []const u8,
    version: []const u8,

    pub fn parseRequestLine(line: []const u8) ?HttpParser {
        var it = std.mem.splitScalar(u8, line, ' ');
        const method = it.next() orelse return null;
        const uri = it.next() orelse return null;
        const version = it.next() orelse return null;

        return HttpParser{
            .method = method,
            .uri = uri,
            .version = version,
        };
    }
};

pub fn main() !void {
}