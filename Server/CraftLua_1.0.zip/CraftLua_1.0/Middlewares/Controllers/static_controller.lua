local M = {}

function M.handle(filepath)
    local file = io.open(filepath, "rb")
    if not file then
        return 404, "text/plain", "File not found"
    end
    local content = file:read("*a")
    file:close()
    return 200, "application/octet-stream", content
end

return M