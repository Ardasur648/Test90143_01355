local M = {}

function M.should_compress(content_type)
    if content_type:match("text/") or content_type:match("application/json") then
        return true
    end
    return false
end

return M