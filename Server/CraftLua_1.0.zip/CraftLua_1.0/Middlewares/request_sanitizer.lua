local M = {}

function M.sanitize(input_string)
    if not input_string then
        return ""
    end
    local clean = input_string:gsub("<script", "&lt;script")
    clean = clean:gsub("javascript:", "")
    return clean
end

return M