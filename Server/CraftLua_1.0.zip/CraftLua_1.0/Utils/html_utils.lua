local M = {}

function M.escape(str)
    if not str then return "" end
    local subs = {["&"]="&amp;", ["<"]="&lt;", [">"]="&gt;", ['"']="&quot;", ["'"]="&#039;"}
    return (str:gsub("[&<>\"']", subs))
end

return M