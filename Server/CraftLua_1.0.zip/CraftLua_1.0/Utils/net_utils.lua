local M = {}

function M.parse_host_port(addr)
    local host, port = addr:match("^(.-):(%d+)$")
    if not host then return addr, 80 end
    return host, tonumber(port)
end

return M