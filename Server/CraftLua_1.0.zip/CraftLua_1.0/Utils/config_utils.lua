local M = {}

function M.parse_line(line)
    local key, val = line:match("^%s*(.-)%s*=%s*(.-)%s*$")
    if key and val then
        return key, val
    end
    return nil, nil
end

return M