local M = {}

function M.join(...)
    local args = {...}
    local path = table.concat(args, "/")
    return path:gsub("/+", "/")
end

function M.extension(filename)
    return filename:match("^.+(%..+)$") or ""
end

return M