local M = {}

function M.copy(t)
    local u = {}
    for k, v in pairs(t) do
        u[k] = type(v) == "table" and M.copy(v) or v
    end
    return setmetatable(u, getmetatable(t))
end

function M.size(t)
    local count = 0
    for _ in pairs(t) do
        count = count + 1
    end
    return count
end

return M