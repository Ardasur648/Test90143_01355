local M = {}

function M.min_max(t)
    if #t == 0 then return 0, 0 end
    local mn, mx = t[1], t[1]
    for i = 2, #t do
        if t[i] < mn then mn = t[i] end
        if t[i] > mx then mx = t[i] end
    end
    return mn, mx
end

return M