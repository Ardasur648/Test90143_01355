local M = {}

math.randomseed(os.time())

function M.string(length)
    local chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
    local res = {}
    for i = 1, length do
        local idx = math.random(1, #chars)
        table.insert(res, chars:sub(idx, idx))
    end
    return table.concat(res)
end

function M.range(min_val, max_val)
    return math.random(min_val, max_val)
end

return M