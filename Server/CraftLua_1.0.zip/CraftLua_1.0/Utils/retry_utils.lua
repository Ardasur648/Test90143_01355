local M = {}

function M.execute(func, retries)
    retries = retries or 3
    for i = 1, retries do
        local ok, err = pcall(func)
        if ok then return true end
    end
    return false
end

return M