local M = {}

function M.clamp(val, lower, upper)
    if val < lower then return lower end
    if val > upper then return upper end
    return val
end

function M.round(val)
    return math.floor(val + 0.5)
end

return M