local M = {}

function M.trim(s)
    return s:match("^%s*(.-)%s*$")
end

function M.starts_with(s, start)
    return s:sub(1, #start) == start
end

function M.ends_with(s, ending)
    return ending == "" or s:sub(-#ending) == ending
end

return M