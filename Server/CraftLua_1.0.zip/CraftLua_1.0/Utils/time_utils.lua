local M = {}

function M.timestamp()
    return os.time()
end

function M.iso8601()
    return os.date("!%Y-%m-%dT%H:%M:%SZ")
end

return M