local M = {}

function M.check(tokens, last_time, max_tokens, refill_rate)
    local now = os.time()
    local elapsed = now - last_time
    tokens = math.min(max_tokens, tokens + elapsed * refill_rate)
    if tokens >= 1 then
        return true, tokens - 1, now
    end
    return false, tokens, now
end

return M