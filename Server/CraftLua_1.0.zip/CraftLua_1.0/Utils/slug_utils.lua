local M = {}

function M.generate(str)
    str = str:lower()
    str = str:gsub("[^%w%s-]", "")
    str = str:gsub("%s+", "-")
    return str
end

return M