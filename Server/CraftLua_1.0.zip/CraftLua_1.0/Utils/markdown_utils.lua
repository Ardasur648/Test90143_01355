local M = {}

function M.bold(text) return "**" .. text .. "**" end
function M.italic(text) return "_" .. text .. "_" end
function M.code(text) return "`" .. text .. "`" end

return M