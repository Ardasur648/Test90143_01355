local M = {}

function M.is_email(email)
    return email:match("^[%w%%_%%+-]+@[%w%%-%%]+%.[%w%%-%%]+$") ~= nil
end

function M.is_ip(ip)
    local a, b, c, d = ip:match("^(%d+)%.(%d+)%.(%d+)%.(%d+)$")
    if not a then return false end
    local t = {tonumber(a), tonumber(b), tonumber(c), tonumber(d)}
    for _, v in ipairs(t) do
        if v < 0 or v > 255 then return false end
    end
    return true
end

return M