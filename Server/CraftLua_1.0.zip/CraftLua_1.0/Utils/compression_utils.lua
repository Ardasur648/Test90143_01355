local M = {}

function M.headers(content_encoding)
    return {
        ["Content-Encoding"] = content_encoding or "identity"
    }
end

return M