local M = {}

function M.calculate(total, page, per_page)
    per_page = per_page or 10
    page = math.max(1, page or 1)
    local total_pages = math.ceil(total / per_page)
    local offset = (page - 1) * per_page
    return offset, per_page, total_pages
end

return M