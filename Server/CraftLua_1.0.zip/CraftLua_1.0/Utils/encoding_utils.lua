local M = {}

function M.to_hex(s)
    return (s:gsub(".", function(c)
        return string.format("%02x", string.byte(c))
    end))
end

function M.from_hex(s)
    return (s:gsub("%x%x", function(hex)
        return string.char(tonumber(hex, 16))
    end))
end

return M