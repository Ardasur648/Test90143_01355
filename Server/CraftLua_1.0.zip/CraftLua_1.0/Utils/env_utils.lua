local M = {}

function M.get(name, default)
    local val = os.getenv(name)
    if val == nil or val == "" then
        return default
    end
    return val
end

return M