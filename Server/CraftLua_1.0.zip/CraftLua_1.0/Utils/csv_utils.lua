local M = {}

function M.parse_line(line)
    local res = {}
    for field in line:gmatch('([^,%s]+)') do
        table.insert(res, field)
    end
    return res
end

return M