local M = {}

function M.xor_encrypt(data, key)
    local res = {}
    for i = 1, #data do
        local b1 = data:byte(i)
        local b2 = key:byte(((i - 1) % #key) + 1)
        table.insert(res, string.char(b1 ~ b2))
    end
    return table.concat(res)
end

return M