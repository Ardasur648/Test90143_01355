local M = {}

function M.red(str) return "\27[31m" .. str .. "\27[0m" end
function M.green(str) return "\27[32m" .. str .. "\27[0m" end
function M.blue(str) return "\27[34m" .. str .. "\27[0m" end

return M