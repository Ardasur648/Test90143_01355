local M = {}

function M.encode(val)
    local t = type(val)
    if t == "string" then
        return '"' .. val:gsub('"', '\\"') .. '"'
    elseif t == "number" or t == "boolean" then
        return tostring(val)
    elseif t == "table" then
        local res = {}
        for k, v in pairs(val) do
            table.insert(res, '"' .. tostring(k) .. '":' .. M.encode(v))
        end
        return "{" .. table.concat(res, ",") .. "}"
    end
    return "null"
end

return M