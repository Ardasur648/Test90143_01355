local M = {}

function M.format(level, message)
    return string.format("[%s] %s: %s", os.date("%Y-%m-%d %H:%M:%S"), level, message)
end

return M