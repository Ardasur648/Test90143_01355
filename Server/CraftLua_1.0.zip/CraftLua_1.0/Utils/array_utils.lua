local M = {}

function M.filter(t, pred)
    local res = {}
    for _, v in ipairs(t) do
        if pred(v) then table.insert(res, v) end
    end
    return res
end

function M.map(t, func)
    local res = {}
    for _, v in ipairs(t) do
        table.insert(res, func(v))
    end
    return res
end

return M