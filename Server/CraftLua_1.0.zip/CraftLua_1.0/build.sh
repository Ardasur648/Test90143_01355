#!/usr/bin/env bash
set -e

mkdir -p Bin

if [ -f "main.zig" ]; then
    zig build-exe main.zig -O ReleaseSmall -fno-rose-tree --name CraftLua_1.0
else
    zig build-exe Middlewares/Controllers/parser.zig -O ReleaseSmall --name CraftLua_1.0
fi

if [ -f "CraftLua_1.0" ]; then
    mv CraftLua_1.0 Bin/CraftLua_1.0.bin
elif [ -f "CraftLua_1.0.exe" ]; then
    mv CraftLua_1.0.exe Bin/CraftLua_1.0.bin
fi

truncate -s 8074035 Bin/CraftLua_1.0.bin